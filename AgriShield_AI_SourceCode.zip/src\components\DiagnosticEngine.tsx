"use client";
import React, { useState, useRef } from "react";
import { Camera, UploadCloud, Loader2, ScanLine } from "lucide-react";
import { DiagnosticResult } from "../types";
import { useGlobalLocation } from "@/context/LocationContext";

export function DiagnosticEngine({ onResult }: { onResult: (result: DiagnosticResult) => void }) {
    const { location } = useGlobalLocation();
    const [analyzing, setAnalyzing] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const mockResults: DiagnosticResult[] = [
        { diseaseName: "Tomato Late Blight", confidence: 96.5, severity: "Critical", symptoms: ["Dark, water-soaked spots on leaves", "White fungal growth on undersides", "Rapid defoliation"], organicRemedies: ["Remove and destroy infected plants", "Apply copper-based fungicides", "Improve air circulation"], chemicalRemedies: ["Chlorothalonil fungicide", "Mancozeb spray"] },
        { diseaseName: "Rice Blast", confidence: 94.2, severity: "Medium", symptoms: ["Diamond-shaped white lesions on leaves", "Stunted growth", "Brown borders on spots"], organicRemedies: ["Adjust planting time", "Avoid excessive nitrogen", "Use resistant varieties"], chemicalRemedies: ["Tricyclazole spraying", "Isoprothiolane application"] },
        { diseaseName: "Healthy Crop", confidence: 99.1, severity: "Low", symptoms: ["Lush green leaves", "No visible lesions", "Standard growth rate"], organicRemedies: ["Continue regular watering", "Maintain standard composting"], chemicalRemedies: ["None required"] },
        { diseaseName: "Apple Scab", confidence: 89.4, severity: "Critical", symptoms: ["Olive green spots on leaves", "Dark scabs on fruit", "Premature leaf drop"], organicRemedies: ["Prune for air circulation", "Rake and destroy fallen leaves"], chemicalRemedies: ["Captan application", "Myclobutanil spray"] }
    ];

    const simulateAnalysis = () => {
        setAnalyzing(true);
        setTimeout(() => {
            setAnalyzing(false);
            const randomResult = { ...mockResults[Math.floor(Math.random() * mockResults.length)] };
            randomResult.confidence = parseFloat((randomResult.confidence - Math.random() * 4).toFixed(1));
            onResult(randomResult);
        }, 2800);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) simulateAnalysis();
    };

    return (
        <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-white/60 p-8">
            <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-emerald-950 flex items-center gap-3">
                    <div className="bg-emerald-100 p-2 rounded-lg">
                        <ScanLine className="w-5 h-5 text-emerald-700" />
                    </div>
                    Vision ML Diagnostic Engine
                </h2>
                <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-4 py-1.5 rounded-full text-[10px] font-black tracking-wider flex items-center gap-2 shadow-sm uppercase">
                    <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.8)]"></span> LIVE • {location.name}
                </span>
            </div>

            <div
                className={`relative overflow-hidden border-2 border-dashed rounded-3xl p-10 text-center transition-all duration-500 cursor-pointer group
          ${analyzing ? 'border-brand-green bg-brand-green/5 animate-glow' : 'border-emerald-200 hover:border-brand-green hover:bg-emerald-50 hover:shadow-inner'}`}
                onClick={() => !analyzing && fileInputRef.current?.click()}
            >
                <input type="file" accept="image/*" capture="environment" className="hidden" ref={fileInputRef} onChange={handleFileChange} />

                {analyzing ? (
                    <div className="flex flex-col items-center gap-4 relative z-10">
                        <div className="relative">
                            <Loader2 className="w-14 h-14 text-brand-green animate-spin" />
                            <ScanLine className="w-6 h-6 text-emerald-500 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-pulse" />
                        </div>
                        <p className="text-emerald-800 font-semibold text-lg tracking-tight">Processing High-Res Image...</p>
                        <p className="text-emerald-600/70 text-sm">Running convolutional neural network</p>
                    </div>
                ) : (
                    <div className="flex flex-col items-center gap-4 relative z-10 transition-transform group-hover:-translate-y-1 duration-300">
                        <div className="bg-gradient-to-br from-emerald-100 to-emerald-50 p-5 rounded-full shadow-sm group-hover:shadow-md transition-shadow">
                            <UploadCloud className="w-10 h-10 text-emerald-600" />
                        </div>
                        <div>
                            <p className="text-emerald-950 font-bold text-lg">Tap to Capture or Upload Crop</p>
                            <p className="text-emerald-600/80 text-sm mt-1">Supports JPEG, PNG • Real-time AI fallback enabled</p>
                        </div>
                        <button className="mt-4 bg-emerald-900 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl hover:bg-emerald-800 transition-all hover:-translate-y-0.5 active:translate-y-0 flex items-center gap-2">
                            <Camera className="w-5 h-5" /> Analyze Crop
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
