"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ScanLine, Map, CloudSun } from "lucide-react";

export function MobileNavigation() {
    const pathname = usePathname();

    const navItems = [
        { name: "Diagnostics", href: "/", icon: ScanLine },
        { name: "Radar", href: "/radar", icon: Map },
        { name: "Weather", href: "/weather", icon: CloudSun },
    ];

    return (
        <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-3xl border-t border-emerald-100/50 shadow-[0_-4px_30px_rgba(5,150,105,0.06)] md:hidden">
            <div className="flex justify-around items-center h-[72px] pb-safe">
                {navItems.map((item) => {
                    const isActive = pathname === item.href;
                    const Icon = item.icon;
                    return (
                        <Link key={item.name} href={item.href} className={`flex flex-col items-center justify-center w-full h-full space-y-1 transition-all duration-300 ${isActive ? 'text-brand-green' : 'text-emerald-900/40 hover:text-emerald-700'}`}>
                            <div className={`relative p-2 rounded-2xl transition-all duration-300 ${isActive ? 'bg-brand-green/10 mb-0.5' : ''}`}>
                                <Icon className={`w-6 h-6 transition-all ${isActive ? 'scale-105 drop-shadow-md' : 'scale-100'}`} />
                            </div>
                            <span className={`text-[10px] font-black tracking-widest transition-all duration-300 uppercase ${isActive ? 'opacity-100 scale-100' : 'opacity-0 scale-90 h-0 w-0 overflow-hidden absolute'}`}>
                                {item.name}
                            </span>
                        </Link>
                    );
                })}
            </div>
        </nav>
    );
}
