"use client";
import { useState } from "react";
import { Header } from "@/components/Header";
import { DiagnosticEngine } from "@/components/DiagnosticEngine";
import { DiagnosticOutput } from "@/components/DiagnosticOutput";
import { WeatherDashboard } from "@/components/WeatherDashboard";
import { DecisionCard } from "@/components/DecisionCard";
import { DiagnosticResult, WeatherData } from "@/types";

export default function Home() {
  const [result, setResult] = useState<DiagnosticResult | null>(null);
  const [weather, setWeather] = useState<WeatherData | null>(null);

  return (
    <div className="min-h-screen flex flex-col pb-20 selection:bg-brand-green/20">
      <Header />
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 md:px-8 flex flex-col gap-8 mt-8">

        <div className="grid lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 flex flex-col gap-8 w-full">
            <DiagnosticEngine onResult={setResult} />
            {result && <DiagnosticOutput result={result} />}
          </div>

          <div className="lg:col-span-4 flex flex-col gap-8 w-full sticky top-28">
            <WeatherDashboard onWeatherUpdate={setWeather} />
            {result && <DecisionCard diagnosis={result} weather={weather} />}
          </div>
        </div>

      </main>
    </div>
  );
}
