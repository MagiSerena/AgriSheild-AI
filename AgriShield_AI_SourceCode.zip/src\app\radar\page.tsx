"use client";
import { Header } from "@/components/Header";
import { AlertCircle, MapPin, Search } from "lucide-react";
import { useGlobalLocation } from "@/context/LocationContext";
import { LocationSearch } from "@/components/LocationSearch";

export default function RadarPage() {
    const { location } = useGlobalLocation();
    const outbreaks = [
        { id: 1, disease: "Maize Fall Armyworm", distance: "2.4 km away", severity: "Critical", time: "10 mins ago", coords: "28.61, 77.21" },
        { id: 2, disease: "Tomato Late Blight", distance: "5.1 km away", severity: "Medium", time: "1 hr ago", coords: "28.64, 77.19" },
        { id: 3, disease: "Wheat Rust", distance: "12.0 km away", severity: "Critical", time: "3 hrs ago", coords: "28.52, 77.29" },
    ];

    return (
        <div className="min-h-screen flex flex-col pb-24 selection:bg-brand-green/20 bg-background">
            <Header />

            <main className="flex-1 w-full max-w-6xl mx-auto px-4 md:px-8 mt-8 flex flex-col gap-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-black text-emerald-950 tracking-tight">Regional Outbreak Radar</h1>
                        <p className="text-emerald-700/80 font-medium">Real-time disease hotspots reported by local agronomists.</p>
                    </div>

                    <div className="w-full md:w-auto">
                        <LocationSearch />
                    </div>
                </div>

                <div className="grid lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 bg-emerald-950 rounded-3xl overflow-hidden relative shadow-[0_8px_30px_rgb(0,0,0,0.12)] h-[400px] lg:h-[600px] border border-emerald-900">
                        {/* Radar Sweep Animation using CSS */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[conic-gradient(from_0deg,transparent_0_340deg,rgba(16,185,129,0.3)_360deg)] rounded-full animate-[spin_4s_linear_infinite] pointer-events-none"></div>

                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center opacity-20 pointer-events-none">
                            <div className="w-[600px] h-[600px] rounded-full border border-emerald-400 absolute"></div>
                            <div className="w-[400px] h-[400px] rounded-full border border-emerald-400 absolute"></div>
                            <div className="w-[200px] h-[200px] rounded-full border border-emerald-400 absolute"></div>
                        </div>

                        {/* Hotspot Pins */}
                        <div className="absolute top-[30%] left-[40%] flex flex-col items-center animate-pulse">
                            <div className="bg-red-500 p-2 rounded-full shadow-[0_0_20px_rgba(239,68,68,0.8)] border-2 border-white/20">
                                <AlertCircle className="w-6 h-6 text-white" />
                            </div>
                            <div className="bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-black text-red-700 mt-2 shadow-lg border border-red-100">Fall Armyworm</div>
                        </div>

                        <div className="absolute top-[60%] left-[70%] flex flex-col items-center">
                            <div className="bg-amber-500 p-2 rounded-full shadow-[0_0_15px_rgba(245,158,11,0.6)] border-2 border-white/20">
                                <AlertCircle className="w-5 h-5 text-white" />
                            </div>
                            <div className="bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-black text-amber-700 mt-2 shadow-lg border border-amber-100">Late Blight</div>
                        </div>

                        <div className="absolute bottom-4 left-4 bg-black/40 backdrop-blur-md text-emerald-50 text-xs px-4 py-2 rounded-full flex items-center gap-2 border border-white/10 font-medium z-20 shadow-lg">
                            <span className="w-2 h-2 bg-brand-green rounded-full animate-pulse shadow-[0_0_10px_rgba(16,185,129,1)]"></span>
                            Tracking • {location.name}
                        </div>
                    </div>

                    <div className="lg:col-span-1 space-y-4">
                        <h3 className="font-bold text-emerald-950 flex items-center gap-2 px-1">
                            <MapPin className="w-5 h-5 text-brand-green" /> Nearby Alerts
                        </h3>

                        <div className="space-y-3">
                            {outbreaks.map((outbreak) => (
                                <div key={outbreak.id} className="bg-white/80 backdrop-blur-xl p-5 rounded-3xl border border-emerald-100/50 shadow-[0_4px_20px_rgb(0,0,0,0.03)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] hover:-translate-y-1 transition-all cursor-pointer">
                                    <div className="flex justify-between items-start mb-2">
                                        <h4 className="font-black text-emerald-950 leading-tight">{outbreak.disease}</h4>
                                        <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-md uppercase tracking-wider ${outbreak.severity === 'Critical' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                                            }`}>
                                            {outbreak.severity}
                                        </span>
                                    </div>
                                    <p className="text-sm font-semibold text-emerald-700/70">{outbreak.distance} • Reported {outbreak.time}</p>
                                </div>
                            ))}
                        </div>

                        <button className="w-full mt-4 bg-emerald-50 text-emerald-800 font-bold py-4 rounded-3xl border border-emerald-200 hover:bg-emerald-100 transition-colors shadow-sm">
                            Report an Outbreak
                        </button>
                    </div>
                </div>
            </main>
        </div>
    );
}
