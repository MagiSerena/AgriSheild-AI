"use client";
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface LocationData {
    name: string;
    lat: number;
    lon: number;
}

interface LocationContextType {
    location: LocationData;
    setLocation: (loc: LocationData) => void;
    searchQuery: string;
    setSearchQuery: (query: string) => void;
}

const defaultLocation: LocationData = {
    name: "Delhi, India",
    lat: 28.6139,
    lon: 77.2090,
};

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export function LocationProvider({ children }: { children: ReactNode }) {
    const [location, setLocationState] = useState<LocationData>(defaultLocation);
    const [searchQuery, setSearchQuery] = useState("");

    useEffect(() => {
        const saved = localStorage.getItem("agrishield_location");
        if (saved) {
            try {
                setLocationState(JSON.parse(saved));
            } catch (e) { }
        }
    }, []);

    const setLocation = (loc: LocationData) => {
        setLocationState(loc);
        localStorage.setItem("agrishield_location", JSON.stringify(loc));
    };

    return (
        <LocationContext.Provider value={{ location, setLocation, searchQuery, setSearchQuery }}>
            {children}
        </LocationContext.Provider>
    );
}

export function useGlobalLocation() {
    const context = useContext(LocationContext);
    if (context === undefined) {
        throw new Error("useGlobalLocation must be used within a LocationProvider");
    }
    return context;
}
