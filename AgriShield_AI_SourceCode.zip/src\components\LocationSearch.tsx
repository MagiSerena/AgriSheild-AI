"use client";
import React, { useState } from "react";
import { Search, Navigation, MapPin } from "lucide-react";
import { useGlobalLocation } from "@/context/LocationContext";

export function LocationSearch() {
    const { location, setLocation, searchQuery, setSearchQuery } = useGlobalLocation();
    const [loading, setLoading] = useState(false);

    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!searchQuery.trim()) return;
        setLoading(true);
        try {
            const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(searchQuery)}&count=1&language=en&format=json`);
            const data = await res.json();
            if (data.results && data.results.length > 0) {
                const place = data.results[0];
                setLocation({
                    name: `${place.name}${place.country ? `, ${place.country}` : ''}`,
                    lat: place.latitude,
                    lon: place.longitude
                });
            } else {
                alert("Location not found. Please try another city.");
            }
        } catch (err) {
            console.error(err);
            alert("Search failed.");
        } finally {
            setLoading(false);
        }
    };

    const handleLocateMe = (e: React.MouseEvent) => {
        e.preventDefault();
        if (navigator.geolocation) {
            setLoading(true);
            setSearchQuery("");
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setLocation({
                        name: "GPS Location",
                        lat: position.coords.latitude,
                        lon: position.coords.longitude
                    });
                    setLoading(false);
                },
                (error) => {
                    console.error(error);
                    setLoading(false);
                    alert("Unable to retrieve location.");
                }
            );
        } else {
            alert("Geolocation not supported.");
        }
    };

    return (
        <div className="flex items-center gap-2 w-full max-w-sm">
            <form onSubmit={handleSearch} className="flex items-center gap-2 relative w-full">
                <MapPin className="w-5 h-5 text-brand-green absolute left-3 pointer-events-none" />
                <input
                    type="text"
                    placeholder={location.name}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-white/60 focus:bg-white hover:bg-white transition-colors border border-emerald-200 text-emerald-950 font-bold text-sm py-2.5 pl-10 pr-10 rounded-xl outline-none placeholder:text-emerald-900/70 shadow-inner focus:shadow-md w-full"
                />
                <button type="submit" className="absolute right-3 hover:scale-110 active:scale-95 transition-transform disabled:opacity-50" disabled={loading}>
                    {loading ? <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div> : <Search className="w-4 h-4 text-emerald-700" />}
                </button>
            </form>
            <button
                onClick={handleLocateMe}
                title="Detect My Location"
                className="bg-emerald-100 hover:bg-emerald-200 text-emerald-800 p-2.5 rounded-xl transition-all border border-emerald-200 shadow-sm flex items-center justify-center flex-shrink-0 active:scale-95"
            >
                <Navigation className="w-4 h-4" />
            </button>
        </div>
    );
}
