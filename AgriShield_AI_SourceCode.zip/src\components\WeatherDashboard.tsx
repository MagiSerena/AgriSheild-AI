"use client";
import React, { useEffect, useState } from "react";
import { Droplets, Wind, CloudFog, Sunrise } from "lucide-react";
import { AreaChart, Area, Tooltip, ResponsiveContainer } from "recharts";
import { WeatherData } from "../types";
import { useGlobalLocation } from "@/context/LocationContext";
import { LocationSearch } from "./LocationSearch";

export function WeatherDashboard({ onWeatherUpdate }: { onWeatherUpdate?: (data: WeatherData | null) => void }) {
    const [weather, setWeather] = useState<WeatherData | null>(null);
    const [loading, setLoading] = useState(true);

    const { location } = useGlobalLocation();

    useEffect(() => {
        async function fetchWeather() {
            setLoading(true);
            try {
                const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${location.lat}&longitude=${location.lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto`);
                const data = await res.json();

                const parsed: WeatherData = {
                    current: { temp: data.current.temperature_2m, humidity: data.current.relative_humidity_2m, windSpeed: data.current.wind_speed_10m },
                    daily: data.daily.time.map((t: string, i: number) => ({
                        date: t,
                        maxTemp: data.daily.temperature_2m_max[i],
                        minTemp: data.daily.temperature_2m_min[i],
                        rainProb: data.daily.precipitation_probability_max[i],
                        shortLabel: new Date(t).toLocaleDateString("en-US", { weekday: 'short' })
                    }))
                };

                setWeather(parsed);
                if (onWeatherUpdate) onWeatherUpdate(parsed);
            } catch (e) {
                console.error("Failed to fetch weather", e);
            } finally {
                setLoading(false);
            }
        }
        fetchWeather();
    }, [location, onWeatherUpdate]);

    const CustomTooltip = ({ active, payload, label }: any) => {
        if (active && payload && payload.length) {
            return (
                <div className="bg-white/90 backdrop-blur border border-emerald-100 p-3 rounded-xl shadow-xl shadow-emerald-900/10 z-50">
                    <p className="font-bold text-emerald-950 text-sm mb-1">{label}</p>
                    <p className="text-brand-soil font-semibold text-xs">High: {payload[0].value}°C</p>
                    <p className="text-emerald-700 font-semibold text-xs">Low: {payload[1].value}°C</p>
                </div>
            );
        }
        return null;
    };

    return (
        <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-white/60 p-6 overflow-hidden relative min-h-[300px]">
            <div className="absolute -top-10 -right-10 opacity-5 pointer-events-none">
                <CloudFog className="w-64 h-64" />
            </div>

            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6 relative z-10 w-full">
                <div>
                    <div className="mb-2">
                        <LocationSearch />
                    </div>
                    <p className="text-emerald-700/70 text-sm font-medium flex items-center gap-1 mt-1 justify-center md:justify-start">
                        <Sunrise className="w-4 h-4" /> Live Weather Profile
                    </p>
                </div>

                {loading ? (
                    <div className="text-emerald-500 font-bold animate-pulse mt-2 md:text-right text-center">Locating...</div>
                ) : weather ? (
                    <div className="text-center md:text-right">
                        <div className="text-4xl font-black tracking-tighter text-emerald-950">{weather.current.temp}°C</div>
                        <div className="text-xs font-semibold text-emerald-700/80 flex gap-3 mt-1 justify-center md:justify-end">
                            <span className="flex items-center justify-end gap-1"><Droplets className="w-3 h-3 text-blue-500" /> {weather.current.humidity}%</span>
                            <span className="flex items-center justify-end gap-1"><Wind className="w-3 h-3 text-slate-400" /> {weather.current.windSpeed} km/h</span>
                        </div>
                    </div>
                ) : <div className="text-red-500 font-medium mt-2 text-center md:text-right">Error Loading</div>}
            </div>

            {weather && !loading && (
                <>
                    <div className="mb-6 h-[100px] -mx-2 relative z-10 animate-in fade-in zoom-in-95 duration-500">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={weather.daily.slice(0, 5)} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                                <defs>
                                    <linearGradient id="colorMax" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#D97706" stopOpacity={0.3} />
                                        <stop offset="95%" stopColor="#D97706" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <Tooltip content={<CustomTooltip />} />
                                <Area type="monotone" dataKey="maxTemp" stroke="#D97706" strokeWidth={3} fillOpacity={1} fill="url(#colorMax)" />
                                <Area type="monotone" dataKey="minTemp" stroke="#059669" strokeWidth={2} strokeDasharray="4 4" fillOpacity={0} />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>

                    <div className="space-y-4 relative z-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <h3 className="font-bold text-emerald-900 border-b border-emerald-100 pb-2 flex items-center justify-between">
                            <span>7-Day Spray Window</span>
                            <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full uppercase tracking-wider">Forecast</span>
                        </h3>
                        <div className="grid grid-cols-7 gap-1.5 overflow-x-auto pb-2 scrollbar-hide">
                            {weather.daily.map((day, i) => {
                                const isRainy = day.rainProb > 40;
                                const badgeBase = "text-[10px] font-extrabold rounded-[4px] w-full text-center py-1 mt-1 transition-all uppercase tracking-wider";
                                const badgeColor = isRainy ? `${badgeBase} bg-red-100 text-red-700 shadow-sm border border-red-200/50` : `${badgeBase} bg-emerald-500 text-white shadow-[0_2px_10px_rgba(16,185,129,0.3)]`;

                                return (
                                    <div key={i} className="flex flex-col items-center justify-between p-2 rounded-xl bg-white/60 border border-emerald-50 hover:bg-white hover:border-emerald-100 hover:shadow-md transition-all min-w-[3.5rem]">
                                        <span className="text-xs font-bold text-emerald-900/60 mb-1">{day.shortLabel}</span>
                                        <span className="text-sm font-black text-emerald-950">{Math.round(day.maxTemp)}°</span>
                                        <span className={badgeColor}>{isRainy ? "Avoid" : "Safe"}</span>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}
