import React from "react";
import { ShieldCheck, ShieldAlert, CloudRain, Sun, Activity } from "lucide-react";
import { DiagnosticResult, WeatherData } from "../types";

export function DecisionCard({ diagnosis, weather }: { diagnosis: DiagnosticResult | null, weather: WeatherData | null }) {
    if (!diagnosis || !weather) return null;

    const isRainExpectedSoon = weather.daily[0].rainProb > 40 || weather.current.windSpeed > 20;
    const isHighSeverity = diagnosis.severity === "Critical" || diagnosis.severity === "Medium";

    const canSpray = !isRainExpectedSoon;

    return (
        <div className={`rounded-3xl shadow-xl p-8 relative overflow-hidden transition-all duration-700 animate-in fade-in slide-in-from-bottom-8
      ${canSpray ? 'bg-gradient-to-br from-brand-green to-emerald-900 border border-brand-green/20' : 'bg-gradient-to-br from-amber-700 to-brand-soil border border-amber-900/20'}`}
        >
            <div className="absolute -top-10 -right-10 opacity-10 pointer-events-none">
                {canSpray ? <ShieldCheck className="w-64 h-64 text-white" /> : <ShieldAlert className="w-64 h-64 text-white" />}
            </div>

            <div className="flex flex-col gap-6 relative z-10">
                <div className="flex items-center gap-3">
                    <div className="bg-white/20 backdrop-blur-md p-3 rounded-2xl shadow-inner">
                        {canSpray ? <ShieldCheck className="w-8 h-8 text-white" /> : <ShieldAlert className="w-8 h-8 text-white" />}
                    </div>
                    <h2 className="text-3xl font-black text-white tracking-tight drop-shadow-md">
                        {canSpray ? "Safe to Apply Treatment" : "Delay Treatment"}
                    </h2>
                </div>

                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 text-white/90 space-y-4">
                    {!canSpray && (
                        <p className="flex items-start gap-3 font-medium text-lg leading-snug">
                            <CloudRain className="w-6 h-6 text-white/80 shrink-0 mt-0.5" />
                            <span>Inclement weather detected. Rain expected soon or winds are too high. Spraying may cause toxic run-off.</span>
                        </p>
                    )}
                    {canSpray && (
                        <p className="flex items-start gap-3 font-medium text-lg leading-snug">
                            <Sun className="w-6 h-6 text-white/80 shrink-0 mt-0.5" />
                            <span>Clear conditions ahead for the next 24-48 hours. This is the optimal window for foliar application.</span>
                        </p>
                    )}

                    {isHighSeverity && (
                        <div className="bg-white/20 rounded-xl p-4 flex gap-3 items-start border border-white/30 shadow-lg mt-4">
                            <Activity className="w-5 h-5 text-white shrink-0 mt-0.5 animate-pulse" />
                            <p className="font-bold text-white text-sm">
                                Critical Alert: Action required immediately to contain {diagnosis.diseaseName} once weather conditions permit safe application.
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
