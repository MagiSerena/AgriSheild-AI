"use client";
import React, { useState } from "react";
import { DiagnosticResult } from "../types";
import { AlertTriangle, Leaf, FlaskConical, Volume2, Info, CheckCircle2 } from "lucide-react";

export function DiagnosticOutput({ result }: { result: DiagnosticResult }) {
    const [isPlaying, setIsPlaying] = useState(false);

    const speak = () => {
        if (!("speechSynthesis" in window)) return;
        if (isPlaying) { window.speechSynthesis.cancel(); setIsPlaying(false); return; }

        const text = `Diagnosis complete. Detected: ${result.diseaseName}. Severity is ${result.severity}. Symptoms include ${result.symptoms.join(", ")}. Organic remedies recommended: ${result.organicRemedies[0]}.`;
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.onend = () => setIsPlaying(false);
        setIsPlaying(true);
        window.speechSynthesis.speak(utterance);
    };

    const severityColor =
        result.severity === "Critical" ? "bg-red-50 text-red-700 border-red-200" :
            result.severity === "Medium" ? "bg-amber-50 text-amber-700 border-amber-200" :
                "bg-emerald-50 text-emerald-700 border-emerald-200";

    const isHealthy = result.severity === "Low";

    return (
        <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-white/60 p-8 space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="flex items-start justify-between gap-4 border-b border-emerald-100/50 pb-6">
                <div>
                    <div className="flex items-center gap-3 mb-2">
                        <h2 className="text-3xl font-black text-emerald-950 tracking-tight">{result.diseaseName}</h2>
                        <span className={`px-4 py-1.5 rounded-full text-xs font-bold border uppercase tracking-wider ${severityColor}`}>
                            {result.severity} Issue
                        </span>
                    </div>
                    <p className="text-emerald-700/80 text-sm flex items-center gap-1.5 font-medium">
                        <Info className="w-4 h-4" /> AI Confidence Score: <strong className="text-emerald-900">{result.confidence}%</strong>
                    </p>
                </div>

                <button
                    onClick={speak}
                    className={`flex-shrink-0 p-4 rounded-2xl transition-all flex items-center justify-center
            ${isPlaying ? 'bg-brand-soil text-white shadow-xl shadow-brand-soil/30 scale-105' : 'bg-white border border-emerald-100 text-emerald-600 hover:bg-emerald-50 hover:shadow-md'}`}
                    title="Listen to Advisory"
                >
                    <Volume2 className={`w-6 h-6 ${isPlaying ? 'animate-pulse' : ''}`} />
                </button>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                    <h3 className="font-bold text-emerald-950 flex items-center gap-2 text-lg">
                        {isHealthy ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <AlertTriangle className="w-5 h-5 text-amber-500" />}
                        Key Visual Findings
                    </h3>
                    <ul className="space-y-3">
                        {result.symptoms.map((symptom, i) => (
                            <li key={i} className="text-sm font-medium text-emerald-800 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100/50 flex items-start gap-3">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" /> {symptom}
                            </li>
                        ))}
                    </ul>
                </div>

                <div className="space-y-6">
                    <div className="space-y-3">
                        <h3 className="font-bold text-emerald-950 flex items-center gap-2 text-lg">
                            <Leaf className="w-5 h-5 text-brand-green" /> Organic Treatments
                        </h3>
                        <ul className="space-y-2 bg-gradient-to-br from-brand-green/10 to-transparent p-4 rounded-2xl border border-brand-green/20">
                            {result.organicRemedies.map((remedy, i) => (
                                <li key={i} className="text-sm font-medium text-emerald-900 flex items-start gap-2">
                                    <span className="text-brand-green font-bold">✓</span> {remedy}
                                </li>
                            ))}
                        </ul>
                    </div>

                    <div className="space-y-3">
                        <h3 className="font-bold text-emerald-950 flex items-center gap-2 text-lg">
                            <FlaskConical className="w-5 h-5 text-brand-soil" /> Chemical Treatments
                        </h3>
                        <ul className="space-y-2 bg-gradient-to-br from-brand-soil/10 to-transparent p-4 rounded-2xl border border-brand-soil/20">
                            {result.chemicalRemedies.map((remedy, i) => (
                                <li key={i} className="text-sm font-medium text-emerald-900 flex items-start gap-2">
                                    <span className="text-brand-soil font-bold">✓</span> {remedy}
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
}
