"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Sprout, Globe } from "lucide-react";

export function Header() {
    const pathname = usePathname();

    return (
        <header className="sticky top-0 z-50 backdrop-blur-xl bg-white/70 border-b border-white/40 shadow-[0_2px_20px_-10px_rgba(0,0,0,0.1)]">
            <div className="max-w-6xl mx-auto flex items-center justify-between p-4">
                <div className="flex items-center gap-8">
                    <Link href="/" className="flex items-center gap-3 group cursor-pointer">
                        <div className="bg-gradient-to-br from-brand-green to-emerald-700 p-2.5 rounded-xl shadow-lg shadow-brand-green/30 transition-transform group-hover:scale-105 group-hover:rotate-3 duration-300">
                            <Sprout className="w-6 h-6 text-white" />
                        </div>
                        <h1 className="text-2xl font-extrabold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-emerald-900 to-brand-green hidden md:block">
                            AgriShield AI
                        </h1>
                    </Link>

                    <div className="hidden md:flex items-center gap-6">
                        <Link href="/" className={`font-semibold transition-colors ${pathname === '/' ? 'text-brand-green' : 'text-emerald-950/60 hover:text-brand-green'}`}>Diagnostics</Link>
                        <Link href="/radar" className={`font-semibold transition-colors ${pathname === '/radar' ? 'text-brand-green' : 'text-emerald-950/60 hover:text-brand-green'}`}>Live Radar</Link>
                    </div>
                </div>

                <div className="flex items-center gap-2 bg-white/60 backdrop-blur-md px-4 py-2 rounded-full border border-emerald-100 shadow-inner hover:bg-white/80 transition-colors">
                    <Globe className="w-4 h-4 text-emerald-600" />
                    <select
                        aria-label="Select Language"
                        className="bg-transparent text-sm font-semibold text-emerald-900 focus:outline-none cursor-pointer appearance-none outline-none pr-1"
                        defaultValue="en"
                    >
                        <option value="en">English</option>
                        <option value="hi">हिंदी</option>
                        <option value="es">Español</option>
                        <option value="fr">Français</option>
                        <option value="sw">Kiswahili</option>
                    </select>
                </div>
            </div>
        </header>
    );
}
