export type Severity = "Low" | "Medium" | "Critical";

export interface DiagnosticResult {
    diseaseName: string;
    confidence: number;
    severity: Severity;
    symptoms: string[];
    organicRemedies: string[];
    chemicalRemedies: string[];
}

export interface WeatherData {
    current: {
        temp: number;
        humidity: number;
        windSpeed: number;
    };
    daily: {
        date: string;
        maxTemp: number;
        minTemp: number;
        rainProb: number;
    }[];
}
